'use strict';
// Defense in depth. Password operations use the fixed native messaging host only.
function blockedNetwork() { throw new Error('Extension network access is disabled'); }
self.fetch = blockedNetwork;
self.XMLHttpRequest = blockedNetwork;
self.WebSocket = blockedNetwork;
self.EventSource = blockedNetwork;
self._opAuthState = { name: 'waiting', params: {} };
const classicHost = '2bua8c4s2c.com.agilebits.1password';
const connectNativeOriginal = chrome.runtime.connectNative.bind(chrome.runtime);
chrome.runtime.connectNative = name => {
  if (name !== classicHost) throw new Error('Unapproved native messaging host');
  return connectNativeOriginal(name);
};
// Packaged local page can display a pairing code, but never a login or password.
chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (!message || message.action !== 'op-local-auth') return false;
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('auth.html')) {
    reply({error:'Untrusted authentication page'});
    return false;
  }
  const auth = self.Authenticator;
  if (!auth) { reply({name:'waiting', params:{}}); return false; }
  if (message.operation === 'ready') auth.authCodeReady();
  else if (message.operation === 'reset') auth.reauthorize();
  else if (message.operation !== 'status') { reply({error:'Unknown operation'}); return false; }
  auth.authPageLoaded(null);
  const state = self._opAuthState || {};
  // Do not forward the authenticator object, secret, or any other fields.
  reply({name:state.name, params:state.name === 'displayCode' ? {code:String(state.params.code)} : {}});
  return false;
});
