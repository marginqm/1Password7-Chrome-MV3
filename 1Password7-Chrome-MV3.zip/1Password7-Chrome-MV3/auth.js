'use strict';
const statusEl = document.getElementById('status');
const codeEl = document.getElementById('code');
const ready = document.getElementById('ready');
async function request(operation) {
  try {
    const state = await chrome.runtime.sendMessage({action:'op-local-auth', operation});
    if (!state) return;
    if (state.error) { statusEl.textContent=state.error; return; }
    if (state.name === 'displayCode') {
      statusEl.textContent='请对照本地配对代码：';
      codeEl.textContent=state.params.code;
      ready.disabled=false;
    } else if (state.name === 'authComplete') {
      statusEl.textContent='本地配对已完成，可以关闭此页。';
      codeEl.textContent=''; ready.disabled=true;
    } else if (state.name === 'noAuth') {
      statusEl.textContent='暂无待确认的配对。请运行 1Password 7 并点击扩展图标。';
      codeEl.textContent=''; ready.disabled=true;
    } else statusEl.textContent='正在等待 1Password 7 扩展助手……';
  } catch (_) { statusEl.textContent='无法连接扩展后台，请查看扩展错误。'; }
}
ready.addEventListener('click',()=>request('ready'));
document.getElementById('reset').addEventListener('click',()=>request('reset'));
request('status');
setInterval(()=>request('status'),1000);
