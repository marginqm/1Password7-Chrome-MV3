// Run original background logic in a simulated worker; no real native host/vault.
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const assert = require('assert');
const crypto = require('crypto');
const root = path.resolve(__dirname, '..');
const listeners = {};
const event = name => ({ addListener(fn) { (listeners[name] ||= []).push(fn); } });
const noop = () => {};
const menus = [], updates = [], created = [], sent = [];
const chrome = {
  action: { onClicked: event('action'), enable: noop, disable: noop },
  contextMenus: { create(p) { menus.push(p); }, removeAll: noop, onClicked: event('menu') },
  runtime: { id:'aomjjhallfgjeglblehebfpbcfeobpgk', getURL:f=>'chrome-extension://aomjjhallfgjeglblehebfpbcfeobpgk/'+f, onMessage: event('message'), getPlatformInfo(cb) { cb({os:'mac', arch:'x86-64'}); },
    connectNative(name) { assert.equal(name, '2bua8c4s2c.com.agilebits.1password'); return { onMessage:event('native-message'), onDisconnect:event('native-disconnect'), postMessage:noop, disconnect:noop }; } },
  tabs: { onUpdated:event('tab-update'), query(p, cb) { cb([{id:1, url:'https://example.test/login'}]); }, sendMessage(id,m,cb) { sent.push([id,m]); if(cb) cb(); }, create(p) { created.push(p); }, update(id,p) { updates.push([id,p]); } },
  windows: { onFocusChanged:event('focus'), WINDOW_ID_CURRENT:-2, WINDOW_ID_NONE:-1, get:noop, getCurrent:noop, create:noop, update:noop },
  webRequest: { onBeforeRequest:event('request'), onCompleted:event('complete') },
  storage: { local: { get(k, cb) { cb({}); }, set(p, cb) { if(cb) cb(); }, remove:noop } }
};
const context = vm.createContext({chrome, console, URL, navigator:{userAgent:'Chrome/153.0.8010.53', platform:'MacIntel'}, crypto:crypto.webcrypto, setTimeout:noop, clearTimeout:noop, btoa:s=>Buffer.from(s,'binary').toString('base64'), atob:s=>Buffer.from(s,'base64').toString('binary')});
context.self = context;
context.importScripts = (...files) => files.forEach(f=>vm.runInContext(fs.readFileSync(path.join(root,f),'utf8'), context, {filename:f}));
vm.runInContext(fs.readFileSync(path.join(root,'background.js'),'utf8'),context,{filename:'background.js'});
assert(context.OnePassword, 'original background loaded');
assert.equal(listeners.action.length,1);
assert.equal(menus.length,1);
assert(menus[0].id && !menus[0].onclick, 'MV3 context menu shim');
let clicked;
context._opToolbarHandler = tab => { clicked = tab.id; };
let response;
listeners.message[1]({action:'op-inline-icon-clicked'}, {tab:{id:3}}, r=>response=r);
assert.equal(clicked,3);
assert.equal(response.success,true);
clicked = null;
listeners.message[1]({action:'op-inline-icon-clicked'}, {}, noop);
assert.equal(clicked,null, 'no invocation without sender tab');
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest.json')));
assert.equal(manifest.manifest_version,3);
for (const f of [manifest.background.service_worker,...manifest.content_scripts.flatMap(c=>[...c.js,...c.css]),...Object.values(manifest.icons)]) assert(fs.existsSync(path.join(root,f)), 'missing resource '+f);
const keyHash=crypto.createHash('sha256').update(Buffer.from(manifest.key,'base64')).digest('hex').slice(0,32);
const id=[...keyHash].map(c=>String.fromCharCode(97+parseInt(c,16))).join('');
assert.equal(id,'aomjjhallfgjeglblehebfpbcfeobpgk');
/* Security regressions */
for (const name of ['fetch','XMLHttpRequest','WebSocket','EventSource']) assert.throws(()=>context[name]('https://canary.invalid/'),/disabled/);
assert.throws(()=>chrome.runtime.connectNative('unexpected.host'),/Unapproved/);
context.AgentHandlers.reportWebsiteIssue({password:'CANARY_NEVER_SEND',url:'https://canary.invalid/'});
assert.equal(created.length,0); assert.equal(updates.length,0);
let rejected;
listeners.message[0]({action:'op-local-auth',operation:'status'}, {id:chrome.runtime.id,url:'https://evil.test/'}, r=>rejected=r);
assert(rejected.error);
context.Authenticator={authPageLoaded(){context._opAuthState={name:'displayCode',params:{code:'123456',secret:'CANARY_NEVER_SEND'}};},authCodeReady:noop,reauthorize:noop};
let localState;
listeners.message[0]({action:'op-local-auth',operation:'status'}, {id:chrome.runtime.id,url:chrome.runtime.getURL('auth.html')}, r=>localState=r);
assert.equal(localState.params.code,'123456'); assert(!JSON.stringify(localState).includes('CANARY_NEVER_SEND'));
let authBlocked;
listeners.message[2]({command:'authCodeReady',params:{}},{tab:{id:1},url:'https://evil.test/'},r=>authBlocked=r);
assert.equal(authBlocked.blocked,true);
const op=context.OnePassword;
assert.equal(op.URLTools.canFillNakedDomainsOnHostname(['example.com'],'evil.test'),false);
assert.equal(op.URLTools.canFillNakedDomainsOnHostname(['example.com'],'example.com.evil.test'),false);
assert.equal(op.URLTools.canFillNakedDomainsOnHostname(['example.com'],'login.example.com'),true);
op.K.testDoc={tabRef:1,documentURL:'https://evil.test/login'};
op.sendExecuteFillScript(true,'testDoc',['example.com'],'test-context',[],{}, {},false,{action:'fillLogin'},noop);
assert.equal(sent.length,0,'refuse credential fill on domain mismatch');
op.K.testDoc.documentURL='https://login.example.com/login';
op.sendExecuteFillScript(true,'testDoc',['example.com'],'test-context',[],{}, {},false,{action:'fillLogin'},noop);
assert.equal(sent.length,1,'retain approved domain fill path');
assert(manifest.content_security_policy.extension_pages.includes("connect-src 'none'"));
assert(!fs.readFileSync(path.join(root,'global.min.js'),'utf8').includes('synapse.agilebits.com'));
assert(!fs.readFileSync(path.join(root,'injected.min.js'),'utf8').includes('ExtensionAuthResponse'));
console.log('PASS: blocked network APIs, fixed native host, removed reporting, local auth sender validation and code-only replies, auth command rejection, cross-domain fill refusal and allowed-domain fill path.');
console.log('PASS: worker initialization, original logic, MV3 menu, explicit inline invocation, resource references, stable extension ID.');
console.log('Simulated APIs only: native authentication and real browser autofill remain unverified.');
